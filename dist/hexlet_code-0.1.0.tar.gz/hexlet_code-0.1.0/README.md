### Hexlet tests and linter status:
[![Actions Status](https://github.com/Yagamama/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Yagamama/python-project-49/actions)
<a href="https://codeclimate.com/github/Yagamama/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b0d1a8541e86b4fab3fa/maintainability" /></a>

https://asciinema.org/a/Dd2S7XPJOnuzWioOOUvnDj5mU

https://asciinema.org/a/7Nbh4VJBz387l7GAtXtYtHFE8